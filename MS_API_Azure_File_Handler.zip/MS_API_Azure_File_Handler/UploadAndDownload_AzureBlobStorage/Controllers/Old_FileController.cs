﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MS_API_Azure_File_Handler.Controllers
{
    public class Old_FileController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

//This section has been added from the original API
//****************************************************
//
//
//
//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Net;
//using System.Net.Http;
//using System.Net.Http.Headers;
//using System.Threading.Tasks;
//using Elleven.API.Gateway.Helpers;
//using Elleven.API.Gateway.Model;
//using IO.Swagger.Monolith.Api;
//using IO.Swagger.Monolith.Client;
//using IO.Swagger.Monolith.Model;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.StaticFiles;

//// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

//namespace Elleven.API.Gateway.Controllers
//{
//    [Route("[controller]")]
//    [AllowAnonymous]
//    public class FileController : Controller
//    {
//        //private readonly ICustomerApi _apiInstance;
//        //private readonly IUploadedFileApi _apiUploadedFileInstance;
//        //private readonly IBlobService _blobService;
//        private readonly IAzureBlobService _azureBlobService;
//        //private readonly ApiClient _apiClient;

//        public FileController(/*ApiClient apiClient, IBlobService blobService, */IAzureBlobService azureBlobService/*, ICustomerApi apiInstance, IUploadedFileApi apiUploadedFileInstance*/)
//        {
//            /*_apiClient = apiClient;
//            _apiUploadedFileInstance = apiUploadedFileInstance;
//            _apiInstance = apiInstance;
//            _blobService = blobService;*/
//            _azureBlobService = azureBlobService;
//        }

//        //[AuthorizePermission(Roles = "User")]
//        [Route("{documentName}/download")]
//        [HttpGet]
//        public async Task<IActionResult> DownloadFile([FromRoute] string documentName)
//        {

//            var data = await _azureBlobService.GetBlobAsync(documentName);

//            Response.Headers.Add("Content-Disposition", "filename=" + documentName + ";");
//            Response.Headers.Add("X-Content-Type-Options", "nosniff");

//            return File(data.Content, data.ContentType);
//        }

//        [Route("upload")]
//        [HttpPost]
//        public async Task<ActionResult> UploadFile()
//        {
//            var request = await HttpContext.Request.ReadFormAsync();
//            if (request.Files == null)
//            {
//                return BadRequest("Could not upload files");
//            }
//            var files = request.Files;
//            if (files.Count == 0)
//            {
//                return BadRequest("Could not upload empty files");
//            }
//            var file = files[0];
//            var fileName = await _azureBlobService.UploadAsync(file);

//            return Ok(fileName);
//        }

//    }
//}
